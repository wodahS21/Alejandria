/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import java.awt.HeadlessException;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class MantenimientoProductos {
PreparedStatement pst;
    BDConexion con;
    private Statement sentenciaSQL;
     ResultSet rs;
    public void RegistroNuevo(Productos prod) {
        String insertar = " INSERT INTO tblproductos(clave,descripcion,stock,precio,ud_medida,fecha_ingreso,no_compra,codigobarras,ruta_imagen,clave_prov,imagen)values(?,?,?,?,?,?,?,?,?,?,?)";
        try {
            FileInputStream archivofoto;
            archivofoto = new FileInputStream(prod.getImagen());
            con = new BDConexion();
            PreparedStatement pst = con.conectarse().prepareStatement(insertar);
              pst.setInt(1, prod.getClave());
            pst.setString(2, prod.getDescripcion());
            pst.setInt(3, prod.getStock());
            pst.setFloat(4, prod.getPrecio());
            pst.setString(5, prod.getUd_medida());
            pst.setDate(6, prod.getFecha_Ingreso());
            pst.setInt(7, prod.getNoCompra());
            pst.setString(8, prod.getCodBarras());
            pst.setString(9, prod.getRutaImagen());
            pst.setInt(10, prod.getClaveProv());
            pst.setBinaryStream(11, archivofoto);
            int n = pst.executeUpdate();
            if (n > 0) {
                JOptionPane.showMessageDialog(null, "registro guardado", "confirmacion", JOptionPane.INFORMATION_MESSAGE);
            }
            con.CerrarConexion();
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Clase no encontrada: " + ex, "error", JOptionPane.ERROR_MESSAGE);
        
    } catch (InstantiationException ex) {
            JOptionPane.showMessageDialog(null, "Error de instancia: " + ex, "error", JOptionPane.ERROR_MESSAGE);
    } catch (IllegalAccessException ex) {
            JOptionPane.showMessageDialog(null, "Mal acceso a la BD: " + ex, "error", JOptionPane.ERROR_MESSAGE);
} catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la sentencia: " + ex, "error", JOptionPane.ERROR_MESSAGE);
} catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error archivo de imagen no encontrada: " + ex, "error", JOptionPane.ERROR_MESSAGE);
}
    }
    public JTable MostrarTabla(JTable tablaDatos){
        try{
              String sql;
            con=new BDConexion();
            sentenciaSQL=con.conectarse().createStatement();
            sql="SELECT * FROM tblproductos";
            ResultSet rs=sentenciaSQL.executeQuery(sql);
            ResultSetMetaData rsm=rs.getMetaData();
            int col=rsm.getColumnCount();
            DefaultTableModel modelo=new DefaultTableModel();
            for (int i = 1; i <= col; i++) {
                modelo.addColumn(rsm.getColumnLabel(i));
            }
            while(rs.next()){
                String fila[]=new String[col];
                  for (int j = 0; j < col; j++) {
                    fila[j]=rs.getString(j+1);
                }
                modelo.addRow(fila);
            }
            tablaDatos.setModel(modelo);
            rs.close();
            con.CerrarConexion();
            
        }catch (ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException ex){
          JOptionPane.showMessageDialog(null, "Error:"+ ex, "Error", JOptionPane.ERROR_MESSAGE);
        }
    return tablaDatos;
    }
      public ImageIcon ObtenerImagen(int clv) throws SQLException {
        InputStream is = null;
        ImageIcon img = null;

        String sql = "SELECT imagen FROM tblproductos WHERE clave=" + clv;
        try {
            con = new BDConexion();
            sentenciaSQL = con.conectarse().createStatement();
            ResultSet rs = sentenciaSQL.executeQuery(sql);
            if (rs.next()) {
                is = rs.getBinaryStream(1);
                BufferedImage bi = ImageIO.read(is);
                img = new ImageIcon(bi);
            }
               
        }catch (IOException | ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e){
          JOptionPane.showMessageDialog(null, "Error:"+ e, "Error", JOptionPane.ERROR_MESSAGE);
        }
        con.CerrarConexion();
        sentenciaSQL.close();
        return img;
            
        }
     public void Actualizar(Productos prod) throws SQLException{
         String sql="UPDATE tblproductos,SET clave=?, descripcion=?,\"\n"+
                 "\"stock=?, precio=?, ud_medida=?,fecha_ingreso=?, no_compra=?,\"\n"+
                 "\"codigobarras=?,ruta_imagen=?,clave_prov=?,imagen=? WHERE clave=?";
         
         try{
             FileInputStream archivofoto;
             archivofoto=new FileInputStream(prod.getImagen());
             
             con=new BDConexion();
             PreparedStatement pst=con.conectarse().prepareStatement(sql);
              pst.setInt(1, prod.getClave());
            pst.setString(2, prod.getDescripcion());
            pst.setInt(3, prod.getStock());
            pst.setFloat(4, prod.getPrecio());
            pst.setString(5, prod.getUd_medida());
            pst.setDate(6, prod.getFecha_Ingreso());
            pst.setInt(7, prod.getNoCompra());
            pst.setString(8, prod.getCodBarras());
            pst.setString(9, prod.getRutaImagen());
            pst.setInt(10, prod.getClaveProv());
            pst.setBinaryStream(11, archivofoto);
            pst.setInt(12, prod.getClave());
            int n=pst.executeUpdate();
            if(n>0){
                JOptionPane.showMessageDialog(null,"Registro modificado","Confirmación", JOptionPane.INFORMATION_MESSAGE);
            }
                
         }catch(HeadlessException | FileNotFoundException | ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e){
           JOptionPane.showMessageDialog(null,"ERROR actualizaer tabla","Verificar", JOptionPane.ERROR_MESSAGE);  
         }
         con.CerrarConexion();
     }
     public void Eliminar(Productos prod){
         try{
    
                     String sql="DELETE FROM tblproductos WHERE clave="+prod.getClave();
                     con=new BDConexion();
                     sentenciaSQL=con.conectarse().createStatement();
                     int n=sentenciaSQL.executeUpdate(sql);
                     if(n>0){
                          JOptionPane.showMessageDialog(null,"Registro Eliminado ","Confirmacion", JOptionPane.INFORMATION_MESSAGE); 
                     }
                     con.CerrarConexion();
                     sentenciaSQL.close();
         }catch(HeadlessException | ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e){
             JOptionPane.showMessageDialog(null,"ERROR"+e,"Verificar", JOptionPane.ERROR_MESSAGE);
         }
     }
     public Vector<Productos> buscarProducto(String buscarProducto) {
        Productos prod;       
        Vector<Productos> vectorProductos = new Vector<Productos>();
         try{
            String sql= "select * from tblproductos  where clave like '%" + buscarProducto + "%'";
            con=new BDConexion();
            pst=con.conectarse().prepareStatement(sql);
            rs = pst.executeQuery();
            
            while (rs.next()) {
                prod = new Productos();
                prod.setClave(rs.getInt("clave"));
                prod.setDescripcion(rs.getString("descripcion"));
                prod.setPrecio(rs.getFloat("precio"));
                prod.setStock(rs.getInt("stock"));
                vectorProductos.add(prod);
            }
           con.CerrarConexion();
        }catch(ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException ex){
            JOptionPane.showMessageDialog(null,"ERROR nombe"+ex,"Verificar", JOptionPane.ERROR_MESSAGE);
        }
        return vectorProductos;
    
    
     }
            
    public int[] BuscarProductoPorID(int idProducto) {
        int datos[] = new int[2];
        try {
            String sql="SELECT , stock FROM tblproductos WHERE clave=?";
            con=new BDConexion();
            pst=con.conectarse().prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                datos[0] = rs.getInt("clave");
                datos[1] = rs.getInt("stock");
            }
            con.CerrarConexion();
        } catch(ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException ex){
            
        }
        return datos;
    }
       public int obtenerStockActual(int idProducto){
        int stockActual = 0;
        try {
            String sql;
            con=new BDConexion();
            sentenciaSQL=con.conectarse().createStatement();
           sql = "SELECT stock FROM tblproductos WHERE clave=?";
            rs = pst.executeQuery(sql);
           pst.setInt(1, idProducto);
            while (rs.next()) {
                stockActual = rs.getInt("stock");
            }
            con.CerrarConexion();
        }  catch(ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException ex){
         
        }
        return stockActual;
    }

    public int actualizarStock(int cantidadActual, int idProducto) {
        int resultado = 0;
        try {
            String sql;
            con=new BDConexion();
            sentenciaSQL=con.conectarse().createStatement();
            sql = "UPDATE tblproductos SET stock=? WHERE clave=?";
            pst.setInt(1, cantidadActual);
            pst.setInt(2, idProducto);
            resultado = pst.executeUpdate();
            con.CerrarConexion();
        }  catch(ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException ex){
          
        }
        return resultado;
    }
}
    





