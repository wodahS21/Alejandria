/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import Datos.Compras;
import Datos.Productos;
import Datos.Ventas;

public class NegocioCompras {

    Compras cp;
    Ventas vt;

    public void PuenteComprar(Productos prod) {
        cp = new Compras();
        cp.Comprar(prod);
    }

    public void PuenteVender(Productos prod) {
        vt = new Ventas();
    }
}
