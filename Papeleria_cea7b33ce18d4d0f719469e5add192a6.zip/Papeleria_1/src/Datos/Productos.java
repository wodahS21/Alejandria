
package Datos;

import java.sql.Date;

public class Productos {
    private int clave;
    private String descripcion;
    private int stock;
    private float precio;
    private String Ud_medida;
    private int claveProv;
    private Date fecha_Ingreso;
    private int noCompra;
    private String CodBarras;
    private String rutaImagen;
    private String imagen;

    public Productos(int clave, String descripcion, int stock, float precio, String Ud_medida, int claveProv, Date fecha_Ingreso, int noCompra, String CodBarras, String rutaImagen, String imagen) {
        this.clave = clave;
        this.descripcion = descripcion;
        this.stock = stock;
        this.precio = precio;
        this.Ud_medida = Ud_medida;
        this.claveProv = claveProv;
        this.fecha_Ingreso = fecha_Ingreso;
        this.noCompra = noCompra;
        this.CodBarras = CodBarras;
        this.rutaImagen = rutaImagen;
        this.imagen = imagen;
    }

    public Productos(){
        
    }

    public int getClave() {
        return clave;
    }

    public void setClave(int clave) {
        this.clave = clave;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getUd_medida() {
        return Ud_medida;
    }

    public void setUd_medida(String Ud_medida) {
        this.Ud_medida = Ud_medida;
    }

    public int getClaveProv() {
        return claveProv;
    }

    public void setClaveProv(int claveProv) {
        this.claveProv = claveProv;
    }

    public Date getFecha_Ingreso() {
        return fecha_Ingreso;
    }

    public void setFecha_Ingreso(Date fecha_Ingreso) {
        this.fecha_Ingreso = fecha_Ingreso;
    }

    public int getNoCompra() {
        return noCompra;
    }

    public void setNoCompra(int noCompra) {
        this.noCompra = noCompra;
    }

    public String getCodBarras() {
        return CodBarras;
    }

    public void setCodBarras(String CodBarras) {
        this.CodBarras = CodBarras;
    }

    public String getRutaImagen() {
        return rutaImagen;
    }

    public void setRutaImagen(String rutaImagen) {
        this.rutaImagen = rutaImagen;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
           
}
