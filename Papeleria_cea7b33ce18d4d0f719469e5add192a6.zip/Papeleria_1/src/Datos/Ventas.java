
package Datos;

import java.util.Date;
import javax.swing.JComboBox;


public class Ventas {
    
    private int folio;

    private String fecha;
    private int cantidad;
    private double monto;


    public Ventas(int folio, String fecha, int cantidad, double monto) {
        this.folio = folio;
        this.fecha = fecha;
        this.cantidad = cantidad;
        this.monto = monto;
 
 
    }

    public Ventas() {
    
 
 
    }

    public int getFolio() {
        return folio;
    }

    public void setFolio(int folio) {
        this.folio = folio;
    }

   
  

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }



    public void setIdcliente(JComboBox<String> cbocliente) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}