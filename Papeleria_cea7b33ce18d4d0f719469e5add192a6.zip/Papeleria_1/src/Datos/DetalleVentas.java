
package Datos;

import java.sql.Date;


public class DetalleVentas {
    
  
    private int folio;
    private int clave;
    private String descripcion;
 
    private float precio;
    private float total;
    private String fecha;

    public DetalleVentas(int folio, int clave, String descripcion, float precio, float total, String fecha) {
       
        this.folio = folio;
        this.clave = clave;
        this.descripcion = descripcion;
      
        this.precio = precio;
        this.total = total;
        this.fecha = fecha;
    }
    public DetalleVentas(){
        
    }

    public int getFolio() {
        return folio;
    }

    public void setFolio(int folio) {
        this.folio = folio;
    }

    public int getClave() {
        return clave;
    }

    public void setClave(int clave) {
        this.clave = clave;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

 
    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

}