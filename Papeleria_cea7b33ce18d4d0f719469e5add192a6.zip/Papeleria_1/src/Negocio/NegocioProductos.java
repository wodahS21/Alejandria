/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import Datos.MantenimientoProductos;
import Datos.Productos;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;

/**
 *
 * @author user
 */
public class NegocioProductos {
    MantenimientoProductos mp;
    
    public void PuenteRegistroNvo(Productos prod){
        mp=new MantenimientoProductos();
        mp.RegistroNuevo(prod);
    }
    public JTable PuenteMostrarTabla(JTable tabladatos){
        mp=new MantenimientoProductos();
        JTable tbl;
        tbl=mp.MostrarTabla(tabladatos);
        
        return tbl;
                
  
    }
    public ImageIcon puenteObtenerImagen(int clv){
         mp=new MantenimientoProductos();
         ImageIcon img=null;
         try{
             img=mp.ObtenerImagen(clv);
         }catch(SQLException e){
             JOptionPane.showMessageDialog(null, "Error: " +e);
    }
         return img;
}
   public void PuenteActualizar(Productos pdto) throws SQLException{
       mp=new MantenimientoProductos();
       mp.Actualizar(pdto);
       
   }
   public void PuenteEliminar (Productos pdto ) throws SQLException{
       mp=new MantenimientoProductos();
       mp.Eliminar(pdto);

}
   public Vector<Productos> consultarCombo() {
        mp = new MantenimientoProductos();
        String buscarProducto = null;
        Vector<Productos> lista = mp.buscarProducto(buscarProducto);
        return lista;
}
}