package Datos;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class MantenimientoVentas {

    BDConexion con;
    PreparedStatement ps;
    ResultSet rs;
    int resultado = 0;
     private Statement sentenciaSQL;

    public int numSerieVentas() {
       int folio = 0;
        try {
              String sql;
            con=new BDConexion();
            sentenciaSQL=con.conectarse().createStatement();
            sql="SELECT max(folio) FROM tblventas";
            ResultSet rs=sentenciaSQL.executeQuery(sql);

            while (rs.next()) {
                folio = rs.getInt(1);
            }
         } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Clase no encontrada: " + ex, "error", JOptionPane.ERROR_MESSAGE);
        
    } catch (InstantiationException ex) {
            JOptionPane.showMessageDialog(null, "Error de instancia: " + ex, "error", JOptionPane.ERROR_MESSAGE);
    } catch (IllegalAccessException ex) {
            JOptionPane.showMessageDialog(null, "Mal acceso a la BD: " + ex, "error", JOptionPane.ERROR_MESSAGE);
} catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la sentencia: " + ex, "error", JOptionPane.ERROR_MESSAGE);
}
        return folio;
    }

    public int guardarVentas(Ventas ven) {
        String insertar = "INSERT INTO tblventas(folio, fecha, cantidad, monto) VALUES (?,?,?,?)";
        try {
            con = new BDConexion();
            PreparedStatement pst = con.conectarse().prepareStatement(insertar);
            pst.setInt(1, ven.getFolio());

            pst.setString(2, ven.getFecha());
            pst.setInt(3, ven.getCantidad());
            pst.setDouble(4, ven.getMonto());
  
            resultado = pst.executeUpdate();
        }catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Clase no encontrada: " + ex, "error", JOptionPane.ERROR_MESSAGE);
        
    } catch (InstantiationException ex) {
            JOptionPane.showMessageDialog(null, "Error de instancia: " + ex, "error", JOptionPane.ERROR_MESSAGE);
    } catch (IllegalAccessException ex) {
            JOptionPane.showMessageDialog(null, "Mal acceso a la BD: " + ex, "error", JOptionPane.ERROR_MESSAGE);
} catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la sentencia: " + ex, "error", JOptionPane.ERROR_MESSAGE);
}
        return resultado;
    }

    public int guardarDetalleVentas(DetalleVentas dellateVenta) {
          String insertar = "INSERT INTO tbldetalle(folio, clave, descripcion, precio, total, fecha) VALUES (?,?,?,?,?,?)";
        try {
            con = new BDConexion();
            PreparedStatement pst = con.conectarse().prepareStatement(insertar);
            pst.setInt(1, dellateVenta.getFolio());
            pst.setInt(2, dellateVenta.getClave());
            pst.setString(3, dellateVenta.getDescripcion());
            pst.setDouble(4, dellateVenta.getPrecio());
            pst.setDouble(5, dellateVenta.getTotal());
            pst.setString(6, dellateVenta.getFecha());
            resultado = pst.executeUpdate();
        } catch (ClassNotFoundException ex) {
           
        
    } catch (InstantiationException ex) {
          
    } catch (IllegalAccessException ex) {
        
} catch (SQLException ex) {
                 }
        return resultado;
    }
    
    public String idVentas() {
        String idVenta = null;
    
        try {
            String sql;
              sentenciaSQL=con.conectarse().createStatement();
            sql="SELECT max(folio) FROM tblventas";
            ResultSet rs=sentenciaSQL.executeQuery(sql);
            while (rs.next()) {
                idVenta = rs.getString(1);
            }
        } catch (SQLException e) {
            System.err.println("Error en : " + e);
        }
        return idVenta;
    }
}
