/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz;

import Datos.Clientes;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import Datos.DetalleVentas;
import Datos.Productos;
import Datos.MantenimientoProductos;
import Datos.Ventas;
import Datos.MantenimientoVentas;
import Negocio.NegocioClientes;
import Negocio.NegocioProductos;

public class InterfazVentas extends javax.swing.JFrame {
 NegocioClientes nc;
 NegocioProductos np;
 ArrayList<Clientes> lista = null;

 
    DefaultComboBoxModel modeloCombo;
    Productos producto = new Productos();
    MantenimientoProductos ma = new MantenimientoProductos();
    MantenimientoVentas mv= new MantenimientoVentas();
    Ventas ventas = new Ventas();
    DetalleVentas detalleVentas = new DetalleVentas();
    DefaultTableModel modeloTabla;
    DecimalFormat decimal = new DecimalFormat("0.00");

    int clave;
    int cantidad;
    int stock;
    double precio;
    double total;
    double totalPagar;
    String fecha;
    int folio;

    public InterfazVentas() {
        
        initComponents();
        diseñoTabla();
        diseñoCantidad();
        calendario();
        generarNumeroSerie();
    }

    private void diseñoCantidad() {
        SpinnerNumberModel modeloSpinner = new SpinnerNumberModel();
        modeloSpinner.setValue(1);
        modeloSpinner.setMinimum(1);
        modeloSpinner.setMaximum(20);
        cantidadCompra.setModel(modeloSpinner);
    }

    private void diseñoTabla() { 
        modeloTabla = new DefaultTableModel();
        tablaVentas.setModel(modeloTabla); 

     
        modeloTabla.addColumn("Orden #");
        modeloTabla.addColumn("C.O.D");
        modeloTabla.addColumn("Producto");
        modeloTabla.addColumn("Cantidad");
        modeloTabla.addColumn("Precio Uni.");
        modeloTabla.addColumn("Total");

  
        int anchoColummna[] = {5, 5, 220, 15, 20, 15};
        boolean cambiarAncho = false;

        for (int i = 0; i < anchoColummna.length; i++) {
            tablaVentas.getColumnModel().getColumn(i).setPreferredWidth(anchoColummna[i]);
            tablaVentas.getColumnModel().getColumn(i).setResizable(cambiarAncho);
        }
    }

    private void calendario() {
        Date fechaActual = new Date();
        SimpleDateFormat formatoSQL = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat gregorian = new SimpleDateFormat("dd-MM-yyyy");
        String fechaSqlFormato = formatoSQL.format(fechaActual);
        String fechaGregorian = gregorian.format(fechaActual);
        txtFecha.setText(String.valueOf(fechaGregorian));
        fecha = fechaSqlFormato;
    }

    private void generarNumeroSerie() {
        int folio = mv.numSerieVentas();
        if (folio == 0) {
            txtSerie.setText("0000001");
        } else {
            int incremento = folio;
            incremento = incremento + 1;
            txtSerie.setText("00000" + incremento);
       
    }
    }
    private void buscarProducto() {
        if (txtBuscarProducto.getText().isEmpty()) {
            JOptionPane.showMessageDialog(panelComponentes, "Debe ingresar un nombre del producto a buscar", "Falta nombre", JOptionPane.WARNING_MESSAGE);
        } else {
            String buscarProducto = txtBuscarProducto.getText();
            Vector<Productos> vectorProductos = new Vector<>();
            vectorProductos = ma.buscarProducto(buscarProducto);
            if (vectorProductos.isEmpty()) {
                JOptionPane.showMessageDialog(panelComponentes, "No existe ese articulo", "No se encontro", JOptionPane.ERROR_MESSAGE);
            } else {
                modeloCombo = new DefaultComboBoxModel(vectorProductos);
                comboProductos.setModel(modeloCombo);
            }

        }
    }

    private void seleccionarProductoComboBox() {
        Productos productoActual = (Productos) comboProductos.getSelectedItem();
        txtIdPro.setText(String.valueOf(productoActual.getClave()));
        txtNombreProducto.setText(productoActual.getDescripcion());
        txtStock.setText(String.valueOf(productoActual.getStock()));
        txtPrecio.setText(String.valueOf(productoActual.getPrecio()));
    }

    public void agregarProductoTabla() {
        if (txtNombreProducto.getText().isEmpty()) {
            JOptionPane.showMessageDialog(panelComponentes, "Primero busque un producto", "Busque producto", JOptionPane.WARNING_MESSAGE);
        } else {
            int item = 0;
            item = item + 1;
            clave = Integer.parseInt(txtIdPro.getText());
            String Descripcion = txtNombreProducto.getText();
            precio = Double.parseDouble(txtPrecio.getText());
            cantidad = Integer.parseInt(cantidadCompra.getValue().toString());
            stock = Integer.parseInt(txtStock.getText());
            total = cantidad * precio;
            ArrayList listaProductos = new ArrayList();
            if (stock > 0) {
                listaProductos.add(item);
                listaProductos.add(clave);
                listaProductos.add(Descripcion);
                listaProductos.add(cantidad);
                listaProductos.add(String.format("%.2f", precio));
                listaProductos.add(String.format("%.2f", total));
                Object[] objDatos = new Object[6];
                objDatos[0] = listaProductos.get(0);
                objDatos[1] = listaProductos.get(1);
                objDatos[2] = listaProductos.get(2);
                objDatos[3] = listaProductos.get(3);
                objDatos[4] = listaProductos.get(4);
                objDatos[5] = listaProductos.get(5);
                modeloTabla.addRow(objDatos);
                totalPagar = totalPagar + total;
                txtTotalPagar.setText(decimal.format(totalPagar));
                limpiarTextoProducto();

            } else {
                JOptionPane.showMessageDialog(panelComponentes, "Articulos en el almacen no disponible", "Falta Stock", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void guardarVenta() {
        if (txtTotalPagar.getText().isEmpty()) {
            JOptionPane.showMessageDialog(panelComponentes, "Agrege productos para hacer la venta", "Agregar productos", JOptionPane.WARNING_MESSAGE);
        } else {
            folio = Integer.parseInt(txtSerie.getText());
            Double monto = totalPagar;
            ventas.setFolio(folio);
            ventas.setFecha(fecha);
            ventas.setMonto(monto);
            ventas.setCantidad(cantidad);
            if (mv.guardarVentas(ventas) > 0) {
                JOptionPane.showMessageDialog(panelComponentes, "Venta Realizada", "Guardado", JOptionPane.INFORMATION_MESSAGE);
                guardarDetalleVentas();
                actualizarStock();
                generarNumeroSerie();
                limpiarVenta();
            } else {
                JOptionPane.showMessageDialog(panelComponentes, "No se guardo la venta", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void guardarDetalleVentas() {
       String idVenta = mv.idVentas();
        int idventa = Integer.parseInt(idVenta);
        for (int i = 0; i < tablaVentas.getRowCount(); i++) {
            int idprod = Integer.parseInt(tablaVentas.getValueAt(i, 1).toString());
            String nomPro = tablaVentas.getValueAt(i, 2).toString();
            float precioProducto = Float.parseFloat(tablaVentas.getValueAt(i, 4).toString());
           float  precioTotal =  Float.parseFloat(tablaVentas.getValueAt(i, 5).toString());
           
            detalleVentas.setFolio(idventa);
            detalleVentas.setClave(idprod);
            detalleVentas.setDescripcion(nomPro);
            detalleVentas.setPrecio(precioProducto);
            detalleVentas.setTotal(precioTotal);
            detalleVentas.setFecha(fecha);
            mv.guardarDetalleVentas(detalleVentas);
        }
    }
  

    public void actualizarStock() {
        int idproducto;
        int datosRecibidos[] = new int[2];
        int idActualizar;
        int cant;
        int cantidadGuardada;
        int stockActual;
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            idproducto = Integer.parseInt(tablaVentas.getValueAt(i, 1).toString());
            datosRecibidos = ma.BuscarProductoPorID(idproducto);
            idActualizar = datosRecibidos[0];
            cant = datosRecibidos[1];
            cantidadGuardada = ma.obtenerStockActual(idActualizar);           
            stockActual = cantidadGuardada - cant;
            ma.actualizarStock(stockActual, idActualizar);
        }
    }

    public void limpiarVenta() {
        txtBuscarProducto.setText(null);
        txtNombreProducto.setText(null);
        txtPrecio.setText(null);
        txtStock.setText(null);
        cantidadCompra.setValue(1);
        txtTotalPagar.setText(null);
        txtIdPro.setText(null);
        modeloTabla.setRowCount(0);
    }

    private void limpiarTextoProducto() {
        txtBuscarProducto.setText(null);
        txtNombreProducto.setText(null);
        txtPrecio.setText(null);
        txtStock.setText(null);
        cantidadCompra.setValue(1);
        txtBuscarProducto.requestFocus();
        txtIdPro.setText(null);
        
    }
    /**
     * Creates new form InterfazVentas
     */
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTabla = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaVentas = new javax.swing.JTable();
        panelComponentes = new javax.swing.JPanel();
        lblCodigoProducto = new javax.swing.JLabel();
        lblPrecio = new javax.swing.JLabel();
        lblCantidad = new javax.swing.JLabel();
        txtBuscarProducto = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        cantidadCompra = new javax.swing.JSpinner();
        btnBuscarProducto = new javax.swing.JButton();
        btnAgregarProducto = new javax.swing.JButton();
        lblProducto = new javax.swing.JLabel();
        lblStock = new javax.swing.JLabel();
        txtNombreProducto = new javax.swing.JTextField();
        txtStock = new javax.swing.JTextField();
        lblBuscar = new javax.swing.JLabel();
        txtIdPro = new javax.swing.JTextField();
        lblNombreProducto = new javax.swing.JLabel();
        comboProductos = new javax.swing.JComboBox<>();
        lblLogo = new javax.swing.JLabel();
        cbocliente = new javax.swing.JComboBox<>();
        lblNombreProducto1 = new javax.swing.JLabel();
        panelVenta = new javax.swing.JPanel();
        btnLimipiarTodo = new javax.swing.JButton();
        btnGenerarVenta = new javax.swing.JButton();
        lblTotalPagar = new javax.swing.JLabel();
        txtTotalPagar = new javax.swing.JTextField();
        btnSalir = new javax.swing.JButton();
        panelTitulos = new javax.swing.JPanel();
        lblDireccion = new javax.swing.JLabel();
        lblSerie = new javax.swing.JLabel();
        txtSerie = new javax.swing.JTextField();
        lblTipoNegocio = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 204, 204));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelTabla.setBackground(new java.awt.Color(204, 255, 255));
        panelTabla.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelTabla.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablaVentas.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        tablaVentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Orden #", "C.O.D", "Producto", "Cantidad", "Precio Uni.", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaVentas.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(tablaVentas);

        panelTabla.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 13, 1166, 350));

        getContentPane().add(panelTabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 424, 1190, -1));

        panelComponentes.setBackground(new java.awt.Color(0, 204, 204));
        panelComponentes.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelComponentes.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblCodigoProducto.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        lblCodigoProducto.setForeground(new java.awt.Color(255, 255, 255));
        lblCodigoProducto.setText("Codigo:");
        panelComponentes.add(lblCodigoProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 74, -1));

        lblPrecio.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        lblPrecio.setForeground(new java.awt.Color(255, 255, 255));
        lblPrecio.setText("Precio:");
        panelComponentes.add(lblPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 74, -1));

        lblCantidad.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        lblCantidad.setForeground(new java.awt.Color(255, 255, 255));
        lblCantidad.setText("Cantidad:");
        panelComponentes.add(lblCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, -1));

        txtBuscarProducto.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        txtBuscarProducto.setToolTipText("Ingrese el nombre del articulo");
        panelComponentes.add(txtBuscarProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 30, 290, 26));

        txtPrecio.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        txtPrecio.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        panelComponentes.add(txtPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 110, 180, 26));

        cantidadCompra.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        panelComponentes.add(cantidadCompra, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 150, 70, 27));

        btnBuscarProducto.setBackground(new java.awt.Color(255, 255, 204));
        btnBuscarProducto.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btnBuscarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Buscar.png"))); // NOI18N
        btnBuscarProducto.setText("Buscar");
        btnBuscarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarProductoActionPerformed(evt);
            }
        });
        panelComponentes.add(btnBuscarProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 170, 150, 70));

        btnAgregarProducto.setBackground(new java.awt.Color(255, 255, 204));
        btnAgregarProducto.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btnAgregarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Agregar.png"))); // NOI18N
        btnAgregarProducto.setText("Agregar");
        btnAgregarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarProductoActionPerformed(evt);
            }
        });
        panelComponentes.add(btnAgregarProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 170, 150, 70));

        lblProducto.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        lblProducto.setForeground(new java.awt.Color(255, 255, 255));
        lblProducto.setText("Nombre Prod:");
        panelComponentes.add(lblProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 80, -1, -1));

        lblStock.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        lblStock.setForeground(new java.awt.Color(255, 255, 255));
        lblStock.setText("Stock:");
        panelComponentes.add(lblStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 120, 106, -1));

        txtNombreProducto.setEditable(false);
        txtNombreProducto.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtNombreProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreProductoActionPerformed(evt);
            }
        });
        panelComponentes.add(txtNombreProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 80, 200, 26));

        txtStock.setEditable(false);
        txtStock.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        panelComponentes.add(txtStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 120, 250, 26));

        lblBuscar.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        lblBuscar.setForeground(new java.awt.Color(255, 255, 255));
        lblBuscar.setText("Buscar:");
        panelComponentes.add(lblBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 74, -1));

        txtIdPro.setEditable(false);
        txtIdPro.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        txtIdPro.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        panelComponentes.add(txtIdPro, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, 210, 26));

        lblNombreProducto.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        lblNombreProducto.setForeground(new java.awt.Color(255, 255, 255));
        lblNombreProducto.setText("Cliente:");
        panelComponentes.add(lblNombreProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, 106, -1));

        comboProductos.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        comboProductos.setMaximumSize(new java.awt.Dimension(250, 32767));
        comboProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboProductosActionPerformed(evt);
            }
        });
        panelComponentes.add(comboProductos, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 30, 270, 26));

        lblLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/logo.jpg"))); // NOI18N
        panelComponentes.add(lblLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 20, 340, 220));

        cbocliente.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        cbocliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                cboclienteFocusGained(evt);
            }
        });
        panelComponentes.add(cbocliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 210, 260, -1));

        lblNombreProducto1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        lblNombreProducto1.setForeground(new java.awt.Color(255, 255, 255));
        lblNombreProducto1.setText("Producto:");
        panelComponentes.add(lblNombreProducto1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 30, 106, -1));

        getContentPane().add(panelComponentes, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 162, -1, 256));

        panelVenta.setBackground(new java.awt.Color(204, 255, 255));
        panelVenta.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelVenta.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnLimipiarTodo.setBackground(new java.awt.Color(255, 255, 204));
        btnLimipiarTodo.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btnLimipiarTodo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Borrar.png"))); // NOI18N
        btnLimipiarTodo.setText("Limpiar");
        btnLimipiarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimipiarTodoActionPerformed(evt);
            }
        });
        panelVenta.add(btnLimipiarTodo, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 0, 190, 50));

        btnGenerarVenta.setBackground(new java.awt.Color(255, 255, 204));
        btnGenerarVenta.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btnGenerarVenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Canasta.png"))); // NOI18N
        btnGenerarVenta.setText("Generar Venta");
        btnGenerarVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarVentaActionPerformed(evt);
            }
        });
        panelVenta.add(btnGenerarVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(463, 1, 170, 50));

        lblTotalPagar.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        lblTotalPagar.setText("Total a pagar:");
        panelVenta.add(lblTotalPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 20, -1, -1));

        txtTotalPagar.setEditable(false);
        txtTotalPagar.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        txtTotalPagar.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        panelVenta.add(txtTotalPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 10, 126, 28));

        btnSalir.setBackground(new java.awt.Color(255, 255, 204));
        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Salir.png"))); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        panelVenta.add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 170, 50));

        getContentPane().add(panelVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 799, 1190, 53));

        panelTitulos.setBackground(new java.awt.Color(0, 204, 204));
        panelTitulos.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panelTitulos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblDireccion.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        lblDireccion.setForeground(new java.awt.Color(255, 255, 255));
        lblDireccion.setText("Direccion: Arenillas - Calle Juan Montalvo y Calle Esmeraldas");
        panelTitulos.add(lblDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 147, -1, -1));

        lblSerie.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        lblSerie.setForeground(new java.awt.Color(255, 255, 255));
        lblSerie.setText("N° de Serie");
        panelTitulos.add(lblSerie, new org.netbeans.lib.awtextra.AbsoluteConstraints(208, 186, -1, -1));

        txtSerie.setEditable(false);
        txtSerie.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 13)); // NOI18N
        panelTitulos.add(txtSerie, new org.netbeans.lib.awtextra.AbsoluteConstraints(288, 184, 100, 25));

        lblTipoNegocio.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        lblTipoNegocio.setForeground(new java.awt.Color(255, 255, 255));
        lblTipoNegocio.setText("Ventas de Artículos Escolares y Oficina");
        panelTitulos.add(lblTipoNegocio, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        txtFecha.setEditable(false);
        txtFecha.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtFecha.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechaActionPerformed(evt);
            }
        });
        panelTitulos.add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 90, 240, 50));

        jLabel5.setBackground(new java.awt.Color(255, 255, 204));
        jLabel5.setFont(new java.awt.Font("Lucida Calligraphy", 1, 48)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Caja");
        jLabel5.setOpaque(true);
        panelTitulos.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 1190, 80));

        getContentPane().add(panelTitulos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 11, 1190, 145));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarProductoActionPerformed
        buscarProducto();
    }//GEN-LAST:event_btnBuscarProductoActionPerformed

    private void btnAgregarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarProductoActionPerformed
        agregarProductoTabla();
    }//GEN-LAST:event_btnAgregarProductoActionPerformed

    private void txtNombreProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreProductoActionPerformed

    private void btnLimipiarTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimipiarTodoActionPerformed
        limpiarVenta();
    }//GEN-LAST:event_btnLimipiarTodoActionPerformed

    private void btnGenerarVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarVentaActionPerformed
        guardarVenta();
    }//GEN-LAST:event_btnGenerarVentaActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    private void txtFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFechaActionPerformed

    private void cboclienteFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cboclienteFocusGained
        nc = new Negocio.NegocioClientes();
        cbocliente.removeAll();
        lista = nc.consultarComboCarrera();
        for (int i = 0; i < lista.size(); i++) {
            cbocliente.addItem(lista.get(i).getNombre());
        }
        
      
    }//GEN-LAST:event_cboclienteFocusGained

    private void comboProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboProductosActionPerformed
        seleccionarProductoComboBox();
    }//GEN-LAST:event_comboProductosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfazVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfazVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfazVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfazVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterfazVentas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarProducto;
    private javax.swing.JButton btnBuscarProducto;
    private javax.swing.JButton btnGenerarVenta;
    private javax.swing.JButton btnLimipiarTodo;
    private javax.swing.JButton btnSalir;
    private javax.swing.JSpinner cantidadCompra;
    private javax.swing.JComboBox<String> cbocliente;
    private javax.swing.JComboBox<String> comboProductos;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JLabel lblCantidad;
    private javax.swing.JLabel lblCodigoProducto;
    private javax.swing.JLabel lblDireccion;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblNombreProducto;
    private javax.swing.JLabel lblNombreProducto1;
    private javax.swing.JLabel lblPrecio;
    private javax.swing.JLabel lblProducto;
    private javax.swing.JLabel lblSerie;
    private javax.swing.JLabel lblStock;
    private javax.swing.JLabel lblTipoNegocio;
    private javax.swing.JLabel lblTotalPagar;
    private javax.swing.JPanel panelComponentes;
    private javax.swing.JPanel panelTabla;
    private javax.swing.JPanel panelTitulos;
    private javax.swing.JPanel panelVenta;
    private javax.swing.JTable tablaVentas;
    private javax.swing.JTextField txtBuscarProducto;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtIdPro;
    private javax.swing.JTextField txtNombreProducto;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtSerie;
    private javax.swing.JTextField txtStock;
    private javax.swing.JTextField txtTotalPagar;
    // End of variables declaration//GEN-END:variables
}
