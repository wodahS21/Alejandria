/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import javax.swing.JTable;
import Datos.MantenimientoProveedores;
import Datos.Proveedores;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author user
 */
public class NegocioProveedores {
    MantenimientoProveedores mp;
   public ArrayList<Proveedores> consultarComboCarrera(){
        mp=new MantenimientoProveedores();
        ArrayList<Proveedores> listaCarrera=mp.Llenarcombo();
        return listaCarrera;
   }

    public JTable PuenteBuscarTabla( JTable tablaProveedor){
       JTable tbl;
       mp=new MantenimientoProveedores();
       tbl=mp.BuscarProveedorTabla(tablaProveedor);
       return tbl;
    }


    public void PuenteRegistroNvo(Proveedores prov){
        mp = new MantenimientoProveedores();
        mp.RegistroProv(prov); 
    }

    public void PuenteActualizar(Proveedores prov) throws SQLException {
        mp = new MantenimientoProveedores();
        mp.Actualizar(prov);
    }

    public void PuenteEliminar(Proveedores prov) throws SQLException {
        mp = new MantenimientoProveedores();
        mp.Eliminar(prov);
    }
    
    public ArrayList<Proveedores> consultarCombo() {
        mp = new MantenimientoProveedores();
        ArrayList<Proveedores> lista = mp.Llenarcombo();
        return lista;
    }

    public ArrayList<Proveedores> PuenteLlenarTabla(int clv) {
        mp = new MantenimientoProveedores();
        ArrayList<Proveedores> lista = mp.Llenartabla(clv);
        return lista;
    }
     public JTable PuenteMostrarTabla(JTable tabladatos){
        mp = new MantenimientoProveedores();
        JTable tbl;
        tbl=mp.MostrarTabla(tabladatos);
        
        return tbl;
}
}